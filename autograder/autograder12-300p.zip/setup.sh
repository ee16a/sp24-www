#!/usr/bin/env bash

apt-get update -y
pip3 uninstall -y pyyaml
pip3 install pyyaml

pip3 install -r /autograder/source/requirements.txt
